<?php
    echo "this is file"
?>